"use client";

import { useEffect, useMemo, useState } from "react";

type Match = {
  id: number;
  date: string;
  league: string;
  country: string;
  leagueLogo: string | null;
  home: { name: string; logo: string | null };
  away: { name: string; logo: string | null };
  apiAvailable: boolean;
  prediction: {
    home: number; draw: number; away: number;
    pick: "HOME" | "DRAW" | "AWAY";
    confidence: number; score: string;
    over25: number; btts: number;
    tier: "HIGH" | "MEDIUM" | "LOW";
    advice: string; source: string;
  };
};

function today() {
  const d = new Date();
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

function pct(n: number) { return `${Math.round(n)}%`; }

function Logo({ src, name }: { src: string | null; name: string }) {
  if (src) return <img className="team-logo" src={src} alt="" />;
  return <div className="team-logo fallback">{name.slice(0,1)}</div>;
}

export default function Home() {
  const [date, setDate] = useState(today());
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [league, setLeague] = useState("ALL");
  const [minConfidence, setMinConfidence] = useState(0);

  async function load() {
    setLoading(true); setError("");
    try {
      const res = await fetch(`/api/matches?date=${date}`, { cache: "no-store" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to load matches.");
      setMatches(data.matches || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to load matches.");
      setMatches([]);
    } finally { setLoading(false); }
  }

  useEffect(() => { load(); }, [date]);

  const leagues = useMemo(() => ["ALL", ...Array.from(new Set(matches.map(m => m.league))).sort()], [matches]);
  const filtered = matches.filter(m => (league === "ALL" || m.league === league) && m.prediction.confidence >= minConfidence);
  const high = matches.filter(m => m.prediction.tier === "HIGH").length;

  return (
    <main>
      <header className="hero">
        <div>
          <div className="eyebrow">ORACLE FC · VERSION 1.0</div>
          <h1>AI Soccer<br /><span>Predictions</span></h1>
          <p>API-Football data + an independent Poisson model for match-specific forecasts.</p>
        </div>
        <div className="status"><span className="dot" /> API READY</div>
      </header>

      <section className="controls">
        <label>Date<input type="date" value={date} onChange={e => setDate(e.target.value)} /></label>
        <label>League<select value={league} onChange={e => setLeague(e.target.value)}>
          {leagues.map(x => <option key={x}>{x}</option>)}
        </select></label>
        <label>Minimum confidence<select value={minConfidence} onChange={e => setMinConfidence(Number(e.target.value))}>
          <option value="0">All</option><option value="50">50%+</option><option value="60">60%+</option><option value="70">70%+</option>
        </select></label>
        <button className="refresh" onClick={load} disabled={loading}>{loading ? "Loading…" : "↻ Refresh"}</button>
      </section>

      <section className="stats">
        <div><small>MATCHES</small><strong>{matches.length}</strong></div>
        <div><small>HIGH CONFIDENCE</small><strong>{high}</strong></div>
        <div><small>MODEL</small><strong>1.0</strong></div>
        <div><small>DATA</small><strong>LIVE</strong></div>
      </section>

      {error && <div className="error"><b>Could not load predictions.</b><br />{error}<br /><small>Check that API_FOOTBALL_KEY is added to Vercel Environment Variables, then redeploy.</small></div>}

      <section className="section-head">
        <div><h2>Today's Forecast</h2><span>{filtered.length} matches shown</span></div>
        <div className="legend"><span>H Home</span><span>D Draw</span><span>A Away</span></div>
      </section>

      {loading && <div className="loading">Fetching fixtures and predictions from API-Football…</div>}
      {!loading && !error && filtered.length === 0 && <div className="empty">No upcoming matches matched your filters for this date.</div>}

      <section className="grid">
        {filtered.map(m => (
          <article className="card" key={m.id}>
            <div className="card-top">
              <span>{m.league}</span>
              <span className={`tier ${m.prediction.tier.toLowerCase()}`}>{m.prediction.tier}</span>
            </div>
            <div className="kickoff">{new Date(m.date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
            <div className="teams">
              <div><Logo src={m.home.logo} name={m.home.name}/><b>{m.home.name}</b></div>
              <span className="vs">VS</span>
              <div><Logo src={m.away.logo} name={m.away.name}/><b>{m.away.name}</b></div>
            </div>

            <div className="prediction">
              <div className="pick"><small>PREDICTION</small><strong>{m.prediction.pick === "HOME" ? "HOME WIN" : m.prediction.pick === "AWAY" ? "AWAY WIN" : "DRAW"}</strong></div>
              <div className="score"><small>EXPECTED SCORE</small><strong>{m.prediction.score}</strong></div>
              <div className="confidence"><small>CONFIDENCE</small><strong>{pct(m.prediction.confidence)}</strong></div>
            </div>

            <div className="bars">
              <div><span>H</span><i><em style={{width:`${m.prediction.home}%`}} /></i><b>{pct(m.prediction.home)}</b></div>
              <div><span>D</span><i><em style={{width:`${m.prediction.draw}%`}} /></i><b>{pct(m.prediction.draw)}</b></div>
              <div><span>A</span><i><em style={{width:`${m.prediction.away}%`}} /></i><b>{pct(m.prediction.away)}</b></div>
            </div>

            <div className="markets">
              <span>Over 2.5 <b>{pct(m.prediction.over25)}</b></span>
              <span>BTTS <b>{pct(m.prediction.btts)}</b></span>
            </div>
            <p className="advice">{m.prediction.advice}</p>
            <footer><span>{m.apiAvailable ? "API prediction + model" : "Model fallback"}</span><span>#{m.id}</span></footer>
          </article>
        ))}
      </section>

      <footer className="page-foot">
        <b>Oracle FC 1.0</b> · Predictions are statistical estimates, not guarantees. Do not use them as certainty for betting decisions.
      </footer>
    </main>
  );
}
