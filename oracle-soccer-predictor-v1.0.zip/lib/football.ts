import { buildPrediction, type ApiPrediction } from "./predictor";

const BASE = "https://v3.football.api-sports.io";

type Fixture = {
  fixture: {
    id: number;
    date: string;
    status: { short: string; long: string };
    venue?: { name?: string | null };
  };
  league: { id: number; name: string; country: string; logo?: string | null; round?: string | null };
  teams: {
    home: { id: number; name: string; logo?: string | null };
    away: { id: number; name: string; logo?: string | null };
  };
  goals?: { home?: number | null; away?: number | null };
};

function apiKey() {
  const key = process.env.API_FOOTBALL_KEY;
  if (!key) throw new Error("API_FOOTBALL_KEY is missing in Vercel Environment Variables.");
  return key;
}

async function api<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "x-apisports-key": apiKey(), "Accept": "application/json" },
    cache: "no-store"
  });

  const text = await res.text();
  let data: any;
  try { data = JSON.parse(text); } catch { throw new Error(`API-Football returned invalid JSON (${res.status}).`); }

  if (!res.ok || (data?.errors && Object.keys(data.errors).length)) {
    throw new Error(data?.errors ? JSON.stringify(data.errors) : `API-Football HTTP ${res.status}`);
  }
  return data as T;
}

function statusUpcoming(short: string) {
  return !["FT","AET","PEN","PST","CANC","ABD","AWD","WO"].includes(short);
}

export async function getMatches(date: string) {
  const fixtureData = await api<{ response: Fixture[] }>(`/fixtures?date=${encodeURIComponent(date)}&timezone=Africa/Windhoek`);
  const fixtures = (fixtureData.response || [])
    .filter(f => statusUpcoming(f.fixture.status.short))
    .sort((a,b) => +new Date(a.fixture.date) - +new Date(b.fixture.date));

  // Keep the default load deliberately small to respect API-Football request quotas.
  const selected = fixtures.slice(0, 12);

  const enriched = await Promise.all(selected.map(async (f) => {
    try {
      const predictionData = await api<{ response: Array<{ predictions?: ApiPrediction }> }>(
        `/predictions?fixture=${f.fixture.id}`
      );
      const apiPrediction = predictionData.response?.[0]?.predictions;
      return {
        id: f.fixture.id,
        date: f.fixture.date,
        league: f.league.name,
        country: f.league.country,
        leagueLogo: f.league.logo || null,
        home: { id: f.teams.home.id, name: f.teams.home.name, logo: f.teams.home.logo || null },
        away: { id: f.teams.away.id, name: f.teams.away.name, logo: f.teams.away.logo || null },
        prediction: buildPrediction(apiPrediction),
        apiAvailable: Boolean(apiPrediction),
      };
    } catch {
      return {
        id: f.fixture.id,
        date: f.fixture.date,
        league: f.league.name,
        country: f.league.country,
        leagueLogo: f.league.logo || null,
        home: { id: f.teams.home.id, name: f.teams.home.name, logo: f.teams.home.logo || null },
        away: { id: f.teams.away.id, name: f.teams.away.name, logo: f.teams.away.logo || null },
        prediction: buildPrediction(undefined),
        apiAvailable: false,
      };
    }
  }));

  return {
    date,
    count: enriched.length,
    matches: enriched,
    generatedAt: new Date().toISOString(),
  };
}
