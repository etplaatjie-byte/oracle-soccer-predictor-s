export type ApiPrediction = {
  winner?: { id?: number | null; name?: string | null; comment?: string | null } | null;
  win_or_draw?: boolean | null;
  under_over?: string | null;
  goals?: { home?: number | null; away?: number | null } | null;
  advice?: string | null;
  percent?: { home?: string | number | null; draw?: string | number | null; away?: string | number | null } | null;
};

export type Prediction = {
  home: number;
  draw: number;
  away: number;
  pick: "HOME" | "DRAW" | "AWAY";
  confidence: number;
  score: string;
  over25: number;
  btts: number;
  tier: "HIGH" | "MEDIUM" | "LOW";
  advice: string;
  source: "API + ORACLE MODEL";
};

function num(value: unknown): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string") {
    const n = Number(value.replace("%", "").trim());
    return Number.isFinite(n) ? n : 0;
  }
  return 0;
}

function normalise(a: number, b: number, c: number) {
  const total = a + b + c;
  if (!total) return { home: 33.3, draw: 33.4, away: 33.3 };
  return {
    home: (a / total) * 100,
    draw: (b / total) * 100,
    away: (c / total) * 100
  };
}

function poisson(k: number, lambda: number) {
  let fact = 1;
  for (let i = 2; i <= k; i++) fact *= i;
  return Math.exp(-lambda) * Math.pow(lambda, k) / fact;
}

function poissonMarkets(homeXg: number, awayXg: number) {
  let home = 0, draw = 0, away = 0, under25 = 0, btts = 0;
  for (let h = 0; h <= 7; h++) {
    for (let a = 0; a <= 7; a++) {
      const p = poisson(h, homeXg) * poisson(a, awayXg);
      if (h > a) home += p;
      else if (h === a) draw += p;
      else away += p;
      if (h + a <= 2) under25 += p;
      if (h > 0 && a > 0) btts += p;
    }
  }
  return { home, draw, away, under25, btts };
}

export function buildPrediction(api: ApiPrediction | undefined): Prediction {
  const apiHome = num(api?.percent?.home);
  const apiDraw = num(api?.percent?.draw);
  const apiAway = num(api?.percent?.away);

  // API-Football predicted goals are used as the expected-goals input.
  // When unavailable, use a neutral prior instead of inventing a team-specific advantage.
  const rawH = num(api?.goals?.home);
  const rawA = num(api?.goals?.away);
  const hxg = Math.max(0.15, Math.min(4.5, rawH || 1.25));
  const axg = Math.max(0.15, Math.min(4.5, rawA || 1.05));

  const p = poissonMarkets(hxg, axg);
  const model = normalise(p.home, p.draw, p.away);
  const apiP = normalise(apiHome || 33.3, apiDraw || 33.4, apiAway || 33.3);

  // Blend the provider forecast and an independent Poisson distribution.
  // This reduces the risk of showing the exact same generic API advice everywhere.
  const blended = normalise(
    model.home * 0.55 + apiP.home * 0.45,
    model.draw * 0.55 + apiP.draw * 0.45,
    model.away * 0.55 + apiP.away * 0.45
  );

  const entries = [
    ["HOME", blended.home],
    ["DRAW", blended.draw],
    ["AWAY", blended.away]
  ] as const;
  entries.sort((x, y) => y[1] - x[1]);
  const pick = entries[0][0];
  const confidence = Math.round(entries[0][1]);
  const tier = confidence >= 68 ? "HIGH" : confidence >= 54 ? "MEDIUM" : "LOW";

  const score = `${Math.max(0, Math.round(hxg))}-${Math.max(0, Math.round(axg))}`;
  const over25 = Math.round((1 - p.under25) * 100);
  const btts = Math.round(p.btts * 100);

  let advice = api?.advice?.trim() || "";
  if (!advice) {
    advice = pick === "HOME" ? "Home win lean" : pick === "AWAY" ? "Away win lean" : "Draw lean";
  }

  return {
    home: Math.round(blended.home * 10) / 10,
    draw: Math.round(blended.draw * 10) / 10,
    away: Math.round(blended.away * 10) / 10,
    pick,
    confidence,
    score,
    over25,
    btts,
    tier,
    advice,
    source: "API + ORACLE MODEL"
  };
}
