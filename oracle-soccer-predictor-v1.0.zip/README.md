# Oracle FC — Soccer Predictor V1.0

A Vercel-ready Next.js application using API-Football.

## What V1.0 does

- Retrieves upcoming fixtures for a selected date.
- Uses API-Football `/fixtures`.
- Uses API-Football `/predictions` for each selected fixture.
- Builds an independent Poisson probability layer from API-predicted expected goals.
- Blends the independent model with API-Football 1X2 probabilities.
- Shows Home / Draw / Away probabilities.
- Shows expected score, Over 2.5 probability and BTTS probability.
- Filters by league and minimum confidence.
- Keeps the API key server-side.
- Limits the default prediction load to 12 matches to help control API quota usage.

## Deploy to Vercel

1. Create a new GitHub repository and upload all files in this folder.
2. Import the repository into Vercel as a Next.js project.
3. In Vercel: Project → Settings → Environment Variables.
4. Add:
   `API_FOOTBALL_KEY`
   with your API-Football key.
5. Apply it to Production and Preview.
6. Redeploy.
7. Open the deployment URL.

Do NOT use `NEXT_PUBLIC_API_FOOTBALL_KEY`. The key must remain server-side.

## Local test

```bash
npm install
cp .env.example .env.local
# put your API key into .env.local
npm run dev
```

Open http://localhost:3000.

## API quota note

API-Football's free plan has a daily request quota. V1.0 deliberately loads only the first 12 upcoming fixtures for a selected date and requests one prediction per fixture. For a larger daily match set, V2 should add caching/database storage and batch-friendly data collection.

## Next upgrades

- league selector based on API league IDs
- recent form and last-5 results
- standings
- team statistics
- H2H
- injuries/lineups
- odds/value analysis
- historical model back-testing
- saved picks
- model accuracy dashboard
- scheduled daily refresh
